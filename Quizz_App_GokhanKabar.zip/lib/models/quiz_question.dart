class QuizQuestion {
  String question;
  bool answer;
  int id;

  QuizQuestion({required this.question, required this.answer, required this.id});
}